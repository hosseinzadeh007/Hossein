using System.Diagnostics;
using System.Windows;
using HesabGara.Data;
using HesabGara.Services;

namespace HesabGara;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        AppFileLogger.Info("شروع حساب‌گرا.");
        ShutdownMode = ShutdownMode.OnExplicitShutdown;
        base.OnStartup(e);
        DispatcherUnhandledException += (_, args) =>
        {
            AppFileLogger.Error("خطای UI مدیریت‌نشده.", args.Exception);
            MessageBox.Show($"خطای غیرمنتظره رخ داد:\n{args.Exception.Message}", "خطای نرم‌افزار", MessageBoxButton.OK, MessageBoxImage.Error);
            args.Handled = true;
        };
        string startupStage = "شروع برنامه";
        try
        {
            AppFileLogger.Info($"نسخه {typeof(App).Assembly.GetName().Version?.ToString(3)}");
            // First-run deployment wizard: choose local SQLite or network SQL Server before database initialization.
            startupStage = "بررسی تنظیمات پایگاه داده";
            if (!File.Exists(DatabaseConfigurationStore.FilePath))
            {
                var setup = new Views.SetupWizardWindow();
                if (setup.ShowDialog() != true || !setup.Completed) { Shutdown(0); return; }
            }
            startupStage = "ایجاد و بازکردن پایگاه داده";
            AppFileLogger.Info("شروع آماده‌سازی پایگاه داده...");
            DatabaseInitializer.Initialize();
            AppFileLogger.Info("پایگاه داده با موفقیت آماده شد.");

            startupStage = "همگام‌سازی مبالغ پرداخت‌شده";
            AppFileLogger.Info("شروع همگام‌سازی مبالغ پرداخت‌شده...");
            new AccountingService().ReconcilePaidAmountsAsync().GetAwaiter().GetResult();
            AppFileLogger.Info("همگام‌سازی مبالغ پرداخت‌شده انجام شد.");

            startupStage = "بازکردن صفحه ورود";
            AppFileLogger.Info("شروع صفحه ورود...");
            var login = new Views.LoginWindow();
            if (login.ShowDialog() != true || login.AuthenticatedUser is null) { Shutdown(0); return; }
            UserSession.Start(login.AuthenticatedUser);
            var main = new Views.MainWindow(login.AuthenticatedUser);
            main.Closed += (_, _) => { UserSession.Clear(); Shutdown(0); };
            main.Show();
        }
        catch (Exception ex)
        {
            ex.Data["StartupStage"] = startupStage;
            AppFileLogger.Error($"خطا در راه‌اندازی برنامه در مرحله «{startupStage}».", ex);
            var stage = ex.Data["StartupStage"]?.ToString() ?? "نامشخص";
            var inner = ex.InnerException is null ? "" : $"\n\nجزئیات داخلی:\n{ex.InnerException}";
            MessageBox.Show($"راه‌اندازی حساب‌گرا انجام نشد.\n\nمرحله: {stage}\n\n{ex.Message}{inner}\n\nگزارش کامل خطا در:\n{AppFileLogger.CurrentLogPath}", "خطای راه‌اندازی", MessageBoxButton.OK, MessageBoxImage.Error);
            if (DatabaseConfigurationStore.Load().Provider == DatabaseProvider.SqlServer
                && MessageBox.Show("اتصال به SQL Server برقرار نشد. می‌خواهید تنظیمات اتصال را از نو انجام دهید (یا به حالت محلی برگردید)؟\nتنظیمات قبلی به‌صورت فایل پشتیبان نگه داشته می‌شود و اطلاعات دیتابیس تغییری نمی‌کند.", "حساب‌گرا", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                try
                {
                    File.Move(DatabaseConfigurationStore.FilePath, DatabaseConfigurationStore.FilePath + ".old-" + DateTime.Now.ToString("yyyyMMdd_HHmmss"), true);
                    Process.Start(new ProcessStartInfo(Environment.ProcessPath!) { UseShellExecute = true });
                }
                catch (Exception restartEx) { AppFileLogger.Error("بازنشانی تنظیمات اتصال ناموفق بود.", restartEx); }
            }
            Shutdown(-1);
        }
    }
}
