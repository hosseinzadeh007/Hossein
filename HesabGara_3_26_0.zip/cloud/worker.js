// حساب‌گرا — واسط ابری (Cloudflare Worker + KV)
// فقط داده‌ی رمزگذاری‌شده‌ی بی‌معنی را نگه می‌دارد؛ رمز هرگز به این‌جا نمی‌رسد.
// ارسال (PUT) فقط با کلید API؛ دریافت (GET) فقط با شناسه‌ی ۱۲۸ بیتی غیرقابل‌حدس کانال.
const MAX_BYTES = 8 * 1024 * 1024;
const TTL_SECONDS = 60 * 60 * 24 * 60; // ۶۰ روز بعد از آخرین ارسال پاک می‌شود
const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET, PUT, OPTIONS', 'Access-Control-Allow-Headers': 'Authorization, Content-Type' };
const json = (o, status = 200) => new Response(JSON.stringify(o), { status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...CORS } });

function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

export default {
  async fetch(req, env) {
    if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: CORS });
    const m = new URL(req.url).pathname.match(/^\/v1\/blob\/([0-9a-f]{32})$/);
    if (!m) return json({ error: 'not_found' }, 404);
    const key = 'blob:' + m[1];

    if (req.method === 'PUT') {
      if (!env.API_KEY || !safeEqual(req.headers.get('Authorization') || '', 'Bearer ' + env.API_KEY)) return json({ error: 'unauthorized' }, 401);
      if ((Number(req.headers.get('Content-Length')) || 0) > MAX_BYTES) return json({ error: 'too_large' }, 413);
      const body = await req.text();
      if (body.length > MAX_BYTES) return json({ error: 'too_large' }, 413);
      try { const e = JSON.parse(body); if (e.v !== 1 || !e.salt || !e.iv || !e.ct) throw 0; } catch { return json({ error: 'bad_envelope' }, 400); }
      const updatedAt = new Date().toISOString();
      await env.STORE.put(key, JSON.stringify({ updatedAt, data: body }), { expirationTtl: TTL_SECONDS });
      return json({ ok: true, updatedAt });
    }

    if (req.method === 'GET') {
      const v = await env.STORE.get(key);
      return v ? new Response(v, { headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store', ...CORS } }) : json({ error: 'empty' }, 404);
    }
    return json({ error: 'method_not_allowed' }, 405);
  }
};
