﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

# اعتبارسنجی نسخه فقط در Release-Preflight.ps1 انجام می‌شود تا دو کپی ناهماهنگ وجود نداشته باشد.
& (Join-Path $PSScriptRoot 'Release-Preflight.ps1')

$Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$version = (Get-Content (Join-Path $Root 'VERSION.txt') -Raw).Trim()
$setup = Join-Path $Root "installer-output\HesabGara_Setup_${version}_win-x64.exe"
if (-not (Test-Path $setup)) { throw "Installer not found (run Production-Release.ps1 first): $setup" }
Write-Host "Release $version validated: $setup" -ForegroundColor Green
