﻿$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$version = (Get-Content (Join-Path $Root 'VERSION.txt') -Raw).Trim()
if ($version -notmatch '^\d+\.\d+\.\d+$') { throw "VERSION.txt is not in x.y.z format: $version" }

foreach ($item in @('HesabGara.csproj', 'HesabGara.sln', 'VERSION.txt', 'Installer\HesabGara.iss', 'Tests\HesabGara.Tests.csproj', 'Assets\HesabGara.ico')) {
  if (-not (Test-Path (Join-Path $Root $item))) { throw "Missing release artifact: $item" }
}

$csproj = Get-Content (Join-Path $Root 'HesabGara.csproj') -Raw
$v = [regex]::Escape($version)
if ($csproj -notmatch "<Version>$v</Version>" -or $csproj -notmatch "<AssemblyVersion>$v\.0</AssemblyVersion>" -or $csproj -notmatch "<FileVersion>$v\.0</FileVersion>") {
  throw "HesabGara.csproj version metadata does not match VERSION.txt ($version)."
}

$iss = Get-Content (Join-Path $Root 'Installer\HesabGara.iss') -Raw
if ($iss -notmatch "#define MyAppVersion `"$v`"" -or $iss -notmatch "VersionInfoVersion=$v\.0" -or $iss -notmatch "VersionInfoProductVersion=$v") {
  throw "Installer\HesabGara.iss version metadata does not match VERSION.txt ($version)."
}

$dotnet = Get-Command dotnet -ErrorAction SilentlyContinue
if (-not $dotnet) { Write-Warning 'dotnet SDK not available: static preflight passed, compile validation remains pending.' }
else {
  $sdks = & $dotnet.Source --list-sdks 2>$null
  if ($LASTEXITCODE -ne 0 -or -not ($sdks -match '^8\.')) { throw 'A .NET 8 SDK is required for this release.' }
}
Write-Host "HesabGara $version release preflight PASSED." -ForegroundColor Green
