using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

/// <summary>اطلاعات چک باید در خروجی و ورودی اکسل حفظ شود.</summary>
public class ExcelCheckRoundTripTests : DatabaseTestBase
{
    static readonly AccountingService S = new();
    static readonly ExcelService Excel = new();

    [Fact]
    public async Task Check_Details_Survive_Export_And_Import()
    {
        var company = new Company { Name = "شرکت چک" };
        await S.AddCompanyAsync(company);
        var invoice = new Invoice { CompanyId = company.Id, Number = "CK-1", Amount = 1000m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(30) };
        await S.AddInvoiceAsync(invoice);
        var checkDate = DateTime.Today.AddDays(15);
        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 400m, PayDate = DateTime.Today, PaymentMethod = PaymentMethods.Check, CheckNumber = "123456", CheckDate = checkDate, CheckStatus = "برگشتی" });

        var xlsxPath = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-check-{Guid.NewGuid():N}.xlsx");
        var importDbPath = Path.Combine(Path.GetTempPath(), $"HesabGara-tests-check-import-{Guid.NewGuid():N}.db");
        try
        {
            await Excel.ExportAsync(xlsxPath);

            AppDbContext.TestDatabasePathOverride.Value = importDbPath;
            using (var initDb = new AppDbContext()) initDb.Database.EnsureCreated();
            var result = await Excel.ImportAsync(xlsxPath);
            Assert.Equal(1, result.PaymentsAdded);
            Assert.Empty(result.Errors);

            var imported = Assert.Single(await S.GetPaymentsAsync());
            Assert.Equal(PaymentMethods.Check, imported.PaymentMethod);
            Assert.Equal("123456", imported.CheckNumber);
            Assert.Equal(checkDate.Date, imported.CheckDate);
            Assert.Equal("برگشتی", imported.CheckStatus);
        }
        finally
        {
            AppDbContext.TestDatabasePathOverride.Value = DatabasePath;
            try { if (File.Exists(xlsxPath)) File.Delete(xlsxPath); } catch { }
            try { if (File.Exists(importDbPath)) File.Delete(importDbPath); } catch { }
        }
    }

    [Fact]
    public void MatchCheckStatus_Accepts_Variants_And_Rejects_Unknown()
    {
        Assert.Equal("وصول\u200cشده", PaymentRules.MatchCheckStatus("وصول شده"));
        Assert.Equal("در انتظار وصول", PaymentRules.MatchCheckStatus(" در انتظار وصول "));
        Assert.Null(PaymentRules.MatchCheckStatus("نامعلوم"));
        Assert.Null(PaymentRules.MatchCheckStatus(""));
    }
}
