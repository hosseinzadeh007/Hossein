using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using HesabGara.Services;
using Xunit;

namespace HesabGara.Tests;

/// <summary>مبلغ پرداخت‌شده‌ی فاکتور باید همیشه برابر جمع رکوردهای Payment باشد.</summary>
public class PaidConsistencyTests : DatabaseTestBase
{
    static readonly AccountingService S = new();

    static async Task<Company> SeedCompanyAsync(string name)
    {
        var company = new Company { Name = name };
        await S.AddCompanyAsync(company);
        return company;
    }

    [Fact]
    public async Task AddInvoice_With_Initial_Paid_Creates_Matching_Payment()
    {
        var company = await SeedCompanyAsync("شرکت الف");
        await S.AddInvoiceAsync(new Invoice { CompanyId = company.Id, Number = "INV-1", Amount = 1000m, Paid = 400m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(10) });

        var stored = (await S.GetInvoicesAsync(company.Id)).Single();
        Assert.Equal(400m, stored.Paid);
        Assert.Equal(400m, Assert.Single(stored.Payments).Amount);
    }

    [Fact]
    public async Task Payment_Cannot_Exceed_Balance_After_Initial_Paid()
    {
        var company = await SeedCompanyAsync("شرکت ب");
        var invoice = new Invoice { CompanyId = company.Id, Number = "INV-1", Amount = 1000m, Paid = 400m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(10) };
        await S.AddInvoiceAsync(invoice);

        await Assert.ThrowsAsync<InvalidOperationException>(() =>
            S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 700m, PayDate = DateTime.Today }));

        await S.AddPaymentAsync(new Payment { InvoiceId = invoice.Id, Amount = 600m, PayDate = DateTime.Today });
        var stored = (await S.GetInvoicesAsync(company.Id)).Single();
        Assert.Equal(0m, AccountingService.Balance(stored));
    }

    [Fact]
    public async Task Legacy_Paid_Without_Payments_Is_Migrated_And_Survives_Reconcile()
    {
        int invoiceId;
        using (var db = new AppDbContext())
        {
            var company = new Company { Name = "شرکت قدیمی" };
            var invoice = new Invoice { Company = company, Number = "OLD-1", Amount = 1000m, Paid = 300m, InvoiceDate = DateTime.Today, DueDate = DateTime.Today.AddDays(5) };
            db.Invoices.Add(invoice);
            db.SaveChanges();
            invoiceId = invoice.Id;
        }

        using (var db = new AppDbContext()) Assert.Equal(1, LegacyPaidMigration.Run(db));
        await S.ReconcilePaidAmountsAsync();

        var stored = (await S.GetInvoicesAsync()).Single(x => x.Id == invoiceId);
        Assert.Equal(300m, stored.Paid);
        Assert.Equal(300m, Assert.Single(stored.Payments).Amount);

        // اجرای دوباره نباید چیزی اضافه کند.
        using (var db = new AppDbContext()) Assert.Equal(0, LegacyPaidMigration.Run(db));
        Assert.Single((await S.GetPaymentsAsync()));
    }

    [Fact]
    public void PaymentMethods_Normalize_Defaults_To_Cash_And_Rejects_Unknown()
    {
        Assert.Equal(PaymentMethods.Cash, PaymentMethods.Normalize("  "));
        Assert.Equal(PaymentMethods.Check, PaymentMethods.Normalize(" چک "));
        Assert.Throws<ArgumentException>(() => PaymentMethods.Normalize("بیت‌کوین"));
    }
}
