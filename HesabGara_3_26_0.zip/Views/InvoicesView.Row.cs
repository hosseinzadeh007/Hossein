using System.ComponentModel;
using HesabGara.Models;
using HesabGara.Services;

namespace HesabGara.Views;

public partial class InvoicesView
{
    /// <summary>یک ردیف از جدول فاکتورها (با قابلیت انتخاب چندتایی).</summary>
    public class Row : INotifyPropertyChanged
    {
        readonly Invoice X;
        bool selected;

        public Row(Invoice x) { X = x; }

        public int Id => X.Id;
        public string Number => X.Number;
        public Company? Company => X.Company;
        public DateTime InvoiceDateValue => X.InvoiceDate;
        public DateTime DueDateValue => X.DueDate;
        public string InvoiceDatePersian => PersianDateService.ToPersian(X.InvoiceDate);
        public string DueDatePersian => PersianDateService.ToPersian(X.DueDate);
        public decimal Amount => X.Amount;
        public decimal Paid => X.Paid;
        public decimal Balance => AccountingService.Balance(X);
        public string? Note => X.Note;

        public bool Selected
        {
            get => selected;
            set
            {
                if (selected == value) return;
                selected = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Selected)));
            }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
    }
}
