using System.IO;
using System.Linq;
using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using Microsoft.Win32;
using System.Windows.Documents;
using HesabGara.Models;
using HesabGara.Services;

namespace HesabGara.Views;

public partial class MainWindow : Window
{
    private readonly AccountingService S = new();
    private readonly BackupService Backup = new();
    private readonly AppUser CurrentUser;
    private List<Invoice> _allInvoices = new();
private static readonly PersianCalendar PC = new();
    private bool _ready;
    private DateTime _lastAutomaticBackup = DateTime.MinValue;
    private bool _backupRunning;

    public MainWindow(AppUser currentUser)
    {
        CurrentUser = currentUser;
        InitializeComponent();
        Loaded += async (_, _) =>
        {
            BtnDashboard.Focus();
            try { await InitializeAsync(); }
            catch (Exception ex)
            {
                try
                {
                    var logDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara");
                    Directory.CreateDirectory(logDir);
                    File.AppendAllText(
                        Path.Combine(logDir, "startup-error.log"),
                        $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] {ex}{Environment.NewLine}{Environment.NewLine}");
                }
                catch { }
                MessageBox.Show(
                    $"راه‌اندازی صفحه اصلی انجام نشد:{Environment.NewLine}{ex.Message}{Environment.NewLine}{Environment.NewLine}گزارش خطا در startup-error.log ذخیره شد.",
                    "خطای راه‌اندازی حساب‌گرا",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        };
        var timer = new System.Windows.Threading.DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
        timer.Tick += async (_, _) => { ClockText.Text = DateTime.Now.ToString("HH:mm:ss"); await AutomaticBackupTickAsync(); };
        timer.Start();
    }

    private async Task InitializeAsync()
    {
        var now = DateTime.Now;
        var py = PC.GetYear(now); var pm = PC.GetMonth(now); var pd = PC.GetDayOfMonth(now);
        ClockText.Text = now.ToString("HH:mm:ss");
        DatabasePathText.Text = HesabGara.Data.AppDbContext.DatabasePath;
        await LoadCompanies();

        await RefreshDashboard();
        _ready = true;
    }

    private async Task AutomaticBackupTickAsync()
    {
        if (!_ready || _backupRunning) return;
        try
        {
            var minutesText = await new SettingsService().GetAsync("AutoBackupMinutes");
            if (!int.TryParse(minutesText, out var minutes) || minutes <= 0) return;
            if ((DateTime.Now - _lastAutomaticBackup).TotalMinutes < minutes) return;
            _backupRunning = true;
            var folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara", "Backups");
            await Backup.CreateBackupAsync(folder);
            _lastAutomaticBackup = DateTime.Now;
            // نگه‌داشتن فقط N پشتیبان خودکار آخر (فقط در پوشه‌ی پشتیبان خودکار؛ پشتیبان‌های دستی هرگز پاک نمی‌شوند).
            var keepText = await new SettingsService().GetAsync(BackupService.KeepCountSettingKey);
            var keep = int.TryParse(keepText, out var k) && k >= 0 ? k : BackupService.DefaultKeepCount;
            BackupService.PruneOldBackups(folder, keep);
            var cloud = CloudSyncSettingsStore.Load();
            if (cloud.AutoSync && cloud.IsConfigured)
            {
                try { await new CloudSyncService().PushAsync(cloud); }
                catch (Exception ex) { AppFileLogger.Error("ارسال خودکار به ابر ناموفق بود.", ex); }
            }
        }
        catch
        {
            // Automatic backup must never interrupt accounting work. Manual backup still reports errors to the user.
        }
        finally { _backupRunning = false; }
    }

    private async Task LoadCompanies()
    {
        var list = await S.GetCompaniesAsync();
        CompanyFilter.ItemsSource = new[] { new Company { Id = 0, Name = "همه" } }.Concat(list).ToList();
        CompanyFilter.DisplayMemberPath = "Name";
        CompanyFilter.SelectedValuePath = "Id";
        CompanyFilter.SelectedIndex = 0;
    }

    private int? SelectedCompanyId => CompanyFilter.SelectedValue is int id && id > 0 ? id : null;

    private async Task RefreshDashboard()
    {
        _allInvoices = await S.GetInvoicesAsync(SelectedCompanyId);
        var companies = await S.GetCompaniesAsync();
        CompaniesCount.Text = companies.Count.ToString("N0");
        ActiveCompanyText.Text = SelectedCompanyId.HasValue ? $"شرکت فعال: {companies.FirstOrDefault(x => x.Id == SelectedCompanyId.Value)?.Name ?? "شرکت انتخاب‌شده"}" : "همه شرکت‌ها";
        DatabaseStatusText.Text = "● پایگاه‌داده آماده";
        BackupStatusText.Text = "پشتیبان‌گیری خودکار فعال";
        InvoicesCount.Text = _allInvoices.Count.ToString("N0");
        TotalInvoices.Text = _allInvoices.Sum(x => x.Amount).ToString("N0");
        TotalPaid.Text = _allInvoices.Sum(x => x.Paid).ToString("N0");
        TotalBalance.Text = _allInvoices.Sum(AccountingService.Balance).ToString("N0");

        LatestInvoices.ItemsSource = _allInvoices.Take(8).Select((x, i) => new
        {
            Row = i + 1,
            Number = x.Number,
            InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate),
            Company = x.Company?.Name ?? "-",
            Amount = x.Amount.ToString("N0"),
            Paid = x.Paid.ToString("N0"),
            Balance = AccountingService.Balance(x).ToString("N0"),
            DueDate = PersianDateService.ToPersian(x.DueDate),
            Status = GetStatus(x)
        }).ToList();

        DueList.Children.Clear();
        var today = DateTime.Today;
        foreach (var x in _allInvoices.Where(x => AccountingService.Balance(x) > 0)
                     .OrderBy(x => x.DueDate).Take(7))
        {
            var days = (x.DueDate.Date - today).Days;
            var color = days < 0 ? "#C4293D" : days <= 7 ? "#C27803" : "#12946B";
            var card = new Border { BorderBrush = AppTheme.Line200, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(7), Padding = new Thickness(9), Margin = new Thickness(0, 4, 0, 4) };
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
            var p = new StackPanel();
            p.Children.Add(new TextBlock { Text = x.Company?.Name ?? "فروشنده", FontWeight = FontWeights.SemiBold, HorizontalAlignment = HorizontalAlignment.Right });
            p.Children.Add(new TextBlock { Text = $"سررسید: {PersianDateService.ToPersian(x.DueDate)}", FontSize = 11, Foreground = AppTheme.Ink500, HorizontalAlignment = HorizontalAlignment.Right });
            Grid.SetColumn(p, 0); g.Children.Add(p);
            var right = new StackPanel { HorizontalAlignment = HorizontalAlignment.Left };
            right.Children.Add(new TextBlock { Text = AccountingService.Balance(x).ToString("N0"), Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)), FontWeight = FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Left });
            right.Children.Add(new Border { Child = new TextBlock { Text = days < 0 ? "گذشته" : $"{days} روز", Foreground = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)), FontSize = 11, HorizontalAlignment = HorizontalAlignment.Center }, BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString(color)), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8), Padding = new Thickness(5, 1, 5, 1), HorizontalAlignment = HorizontalAlignment.Left });
            Grid.SetColumn(right, 1); g.Children.Add(right);
            card.Child = g; DueList.Children.Add(card);
        }
    }

    private static string GetStatus(Invoice x)
    {
        var b = AccountingService.Balance(x);
        if (b <= 0) return "تسویه شده";
        if (x.Paid > 0) return "بخشی پرداخت شده";
        return "پرداخت نشده";
    }


    private void Dashboard_Click(object sender, RoutedEventArgs e) { PageHost.Content = DashboardScroll; SetActiveNav(BtnDashboard); }

    private void Calculator_Click(object sender, RoutedEventArgs e)
    {
        try { Process.Start(new ProcessStartInfo("calc.exe") { UseShellExecute = true }); }
        catch (Exception ex) { MessageBox.Show("ماشین حساب ویندوز اجرا نشد: " + ex.Message, "ماشین حساب", MessageBoxButton.OK, MessageBoxImage.Warning); }
    }

    private void Calendar_Click(object sender, RoutedEventArgs e)
    {
        var w = new Window { Title = "تقویم", Width = 320, Height = 400, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, FlowDirection = FlowDirection.RightToLeft, Background = AppTheme.Surface100, ResizeMode = ResizeMode.NoResize };
        w.Content = BuildPersianCalendarPanel();
        w.ShowDialog();
    }

    // چون کنترل استاندارد Calendar در WPF فقط تقویم میلادی را درست نمایش می‌دهد (به تقویم
    // شمسی سوییچ نمی‌شود)، یک نمای ماهانه‌ی شمسی کاملاً دستی با PersianCalendar ساخته می‌شود
    // تا نمایش تاریخ‌ها تضمینی درست باشد.
    static FrameworkElement BuildPersianCalendarPanel()
    {
        var pc = new PersianCalendar();
        var today = DateTime.Today;
        int year = pc.GetYear(today), month = pc.GetMonth(today);
        string[] monthNames = {"فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند"};
        string[] dayNames = {"ش","ی","د","س","چ","پ","ج"};

        var headerText = new TextBlock { FontWeight = FontWeights.Bold, FontSize = 15, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center, Foreground = AppTheme.Brand900 };
        var grid = new UniformGrid { Columns = 7 };
        var todayText = new TextBlock { Foreground = AppTheme.Ink500, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0,12,0,0) };

        void Render()
        {
            grid.Children.Clear();
            headerText.Text = $"{monthNames[month-1]} {year}";
            foreach (var d in dayNames)
                grid.Children.Add(new TextBlock{Text=d,FontWeight=FontWeights.SemiBold,HorizontalAlignment=HorizontalAlignment.Center,Margin=new Thickness(2,4,2,8),Foreground=AppTheme.Ink500});

            var firstOfMonth = pc.ToDateTime(year, month, 1, 0, 0, 0, 0);
            // هفته‌ی شمسی از شنبه شروع می‌شود؛ DayOfWeek میلادی از یکشنبه=0 است، پس جابه‌جا می‌شود.
            int offset = ((int)firstOfMonth.DayOfWeek + 1) % 7;
            for (int i = 0; i < offset; i++) grid.Children.Add(new TextBlock());

            int daysInMonth = pc.GetDaysInMonth(year, month);
            for (int day = 1; day <= daysInMonth; day++)
            {
                var dt = pc.ToDateTime(year, month, day, 0, 0, 0, 0);
                var isToday = dt.Date == today;
                var cell = new Border{ Margin = new Thickness(2), CornerRadius = new CornerRadius(16), Width = 32, Height = 32,
                    Background = isToday ? AppTheme.Brand600 : Brushes.Transparent };
                cell.Child = new TextBlock{ Text = day.ToString(), HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center,
                    Foreground = isToday ? Brushes.White : AppTheme.Ink900, FontWeight = isToday ? FontWeights.Bold : FontWeights.Normal };
                grid.Children.Add(cell);
            }
        }
        Render();

        var prevBtn = new Button{ Content = "◀", Width = 34, Height = 30, Background = AppTheme.Surface100, BorderThickness = new Thickness(0), Foreground = AppTheme.Ink700 };
        var nextBtn = new Button{ Content = "▶", Width = 34, Height = 30, Background = AppTheme.Surface100, BorderThickness = new Thickness(0), Foreground = AppTheme.Ink700 };
        prevBtn.Click += (_, _) => { month--; if (month < 1) { month = 12; year--; } Render(); };
        nextBtn.Click += (_, _) => { month++; if (month > 12) { month = 1; year++; } Render(); };

        var navRow = new Grid();
        navRow.ColumnDefinitions.Add(new ColumnDefinition{ Width = GridLength.Auto });
        navRow.ColumnDefinitions.Add(new ColumnDefinition{ Width = new GridLength(1, GridUnitType.Star) });
        navRow.ColumnDefinitions.Add(new ColumnDefinition{ Width = GridLength.Auto });
        Grid.SetColumn(prevBtn,0); Grid.SetColumn(headerText,1); Grid.SetColumn(nextBtn,2);
        navRow.Children.Add(prevBtn); navRow.Children.Add(headerText); navRow.Children.Add(nextBtn);

        todayText.Text = $"امروز: {PersianDateService.ToPersian(today)}";

        var root = new StackPanel { Margin = new Thickness(18) };
        root.Children.Add(navRow);
        root.Children.Add(new Separator{ Margin = new Thickness(0,10,0,10) });
        root.Children.Add(grid);
        root.Children.Add(todayText);
        return root;
    }

    private async void LocalUpdate_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin)
        {
            MessageBox.Show("فقط مدیر سیستم می‌تواند نرم‌افزار را به‌روزرسانی کند.", "به‌روزرسانی محلی", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var dialog = new OpenFileDialog
        {
            Filter = "بسته به‌روزرسانی حساب‌گرا|*.zip",
            Title = "انتخاب بسته به‌روزرسانی محلی حساب‌گرا",
            CheckFileExists = true,
            Multiselect = false
        };
        if (dialog.ShowDialog() != true) return;

        LocalUpdateService.UpdatePackage package;
        try
        {
            package = LocalUpdateService.Inspect(dialog.FileName);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "بسته نامعتبر", MessageBoxButton.OK, MessageBoxImage.Error);
            return;
        }

        var current = LocalUpdateService.CurrentVersion;
        var target = AppContext.BaseDirectory.TrimEnd(Path.DirectorySeparatorChar, Path.AltDirectorySeparatorChar);
        var confirm = MessageBox.Show(
            $"نسخه فعلی: {current}\nنسخه بسته: {package.Version}\n\nمحل نصب فعلی:\n{target}\n\nقبل از به‌روزرسانی یک پشتیبان از اطلاعات تهیه می‌شود.\nبرنامه بسته شده و پس از نصب مجدداً اجرا خواهد شد.\n\nآیا ادامه می‌دهید؟",
            "به‌روزرسانی محلی حساب‌گرا",
            MessageBoxButton.YesNo,
            MessageBoxImage.Question);

        if (confirm != MessageBoxResult.Yes)
        {
            try { Directory.Delete(package.ExtractedRoot, true); } catch { }
            return;
        }

        try
        {
            var backupFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "HesabGara", "Backups");
            await Backup.CreateBackupAsync(backupFolder);
            LocalUpdateService.StartUpdate(package, target);
            MessageBox.Show("به‌روزرسانی آماده اجراست. حساب‌گرا اکنون بسته و پس از نصب نسخه جدید دوباره اجرا می‌شود.", "به‌روزرسانی", MessageBoxButton.OK, MessageBoxImage.Information);
            Application.Current.Shutdown(0);
        }
        catch (Exception ex)
        {
            try { Directory.Delete(package.ExtractedRoot, true); } catch { }
            MessageBox.Show("شروع به‌روزرسانی انجام نشد:\n" + ex.Message, "خطای به‌روزرسانی", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void About_Click(object sender, RoutedEventArgs e)
    {
        var w = new Window { Title = "درباره حساب‌گرا", Width = 620, Height = 430, Owner = this, WindowStartupLocation = WindowStartupLocation.CenterOwner, FlowDirection = FlowDirection.RightToLeft, Background = Brushes.White };
        var p = new StackPanel { Margin = new Thickness(36), VerticalAlignment = VerticalAlignment.Center };
        p.Children.Add(new TextBlock { Text = "حساب‌گرا", FontSize = 38, FontWeight = FontWeights.Bold, Foreground = AppTheme.Brand900, HorizontalAlignment = HorizontalAlignment.Center });
        p.Children.Add(new TextBlock { Text = "نرم‌افزار حسابداری و مدیریت خرید", FontSize = 18, Foreground = AppTheme.Brand600, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(0,5,0,24) });
        var currentVersion = typeof(App).Assembly.GetName().Version?.ToString(3) ?? LocalUpdateService.CurrentVersion;
        p.Children.Add(new TextBlock { Text = $"نسخه: {currentVersion}\nتوسعه‌دهنده: حسین حسین زاده\nایمیل: Hzadeh007@gmail.com\nقابلیت‌ها: مدیریت شرکت‌ها، فاکتورها، پرداخت‌ها، سررسیدها، گزارش‌های تفکیک‌شده و Excel\nپایگاه داده: SQLite / SQL Server\nچارچوب: .NET 8 / WPF", FontSize = 15, Foreground = AppTheme.Ink700, TextAlignment = TextAlignment.Center, TextWrapping = TextWrapping.Wrap, LineHeight = 30 });
        w.Content = p; w.ShowDialog();
    }
    private void Companies_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanManageData) { MessageBox.Show("دسترسی مدیریت داده لازم است."); return; }
        PageHost.Content = new CompaniesView(S, LoadCompanies); SetActiveNav(BtnCompanies); }
    private void Invoices_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanManageData) { MessageBox.Show("دسترسی مدیریت داده لازم است."); return; }
        PageHost.Content = new InvoicesView(S, SelectedCompanyId); SetActiveNav(BtnInvoices); }
    private async void Reports_Click(object sender, RoutedEventArgs e) { if (!CurrentUser.IsAdmin && !CurrentUser.CanViewReports) { MessageBox.Show("دسترسی گزارش لازم است."); return; }
        PageHost.Content = await ReportsView.Create(S, SelectedCompanyId); SetActiveNav(BtnReports); }

    // به‌جای باز کردن یک پنجره‌ی جدید برای هر بخش، کل ناحیه‌ی صفحه (PageHost) با محتوای همان
    // بخش جایگزین می‌شود - دقیقاً مثل یک برنامه‌ی تک‌صفحه‌ای که فقط تب فعال را عوض می‌کند.
    void SetActiveNav(Button active)
    {
        foreach (var btn in new[] { BtnDashboard, BtnCompanies, BtnInvoices, BtnReports, BtnUsers, BtnSettings })
            btn.Style = (Style)FindResource(btn == active ? "NavButtonActive" : "NavButton");
    }
    private async void ImportExcel_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanImportExport) { MessageBox.Show("دسترسی Excel لازم است."); return; }
        var choice = MessageBox.Show(
            "اگر فایل Excel آماده دارید «Yes» را بزنید.\nاگر فایل ندارید و می‌خواهید ابتدا یک قالب ساده دانلود کنید، «No» را بزنید.",
            "ورود اطلاعات از Excel", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (choice == MessageBoxResult.No)
        {
            var sd = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx", FileName = "قالب-ساده-ورود-فاکتور.xlsx" };
            if (sd.ShowDialog() == true)
            {
                try
                {
                    new ExcelService().ExportSimpleTemplate(sd.FileName);
                    MessageBox.Show("قالب ساده ذخیره شد. آن را با اطلاعات خودتان پر کنید (فقط نام شرکت، شماره فاکتور و مبلغ لازم است) و دوباره از همین گزینه، فایل پرشده را وارد کنید.", "قالب ساده", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex) { MessageBox.Show(ex.Message, "خطا", MessageBoxButton.OK, MessageBoxImage.Error); }
            }
            return;
        }
        var d = new OpenFileDialog { Filter = "Excel Workbook|*.xlsx;*.xlsm", Title = "انتخاب فایل Excel برای ورود اطلاعات" };
        if (d.ShowDialog() != true) return;
        try
        {
            var result = await new ExcelService().ImportAsync(d.FileName);
            await LoadCompanies();
            await RefreshDashboard();
            var msg = $"ورود Excel انجام شد.\n\nشرکت‌های جدید: {result.CompaniesAdded:N0}\nشرکت‌های تکراری/ردشده: {result.CompaniesSkipped:N0}\nفاکتورهای جدید: {result.InvoicesAdded:N0}\nفاکتورهای تکراری/ردشده: {result.InvoicesSkipped:N0}\nپرداخت‌های جدید: {result.PaymentsAdded:N0}\nپرداخت‌های تکراری/ردشده: {result.PaymentsSkipped:N0}";
            if (result.Errors.Count > 0) msg += $"\n\nهشدار/خطا: {result.Errors.Count:N0} مورد";
            MessageBox.Show(msg, "نتیجه ورود Excel", MessageBoxButton.OK, result.Errors.Count > 0 ? MessageBoxImage.Warning : MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show("ورود Excel انجام نشد: " + ex.Message, "خطا", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void ExportExcel_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanImportExport) { MessageBox.Show("دسترسی Excel لازم است."); return; }
        var d = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx", Title = "ذخیره خروجی Excel", FileName = $"accounting-export-{DateTime.Now:yyyyMMdd-HHmm}.xlsx" };
        if (d.ShowDialog() != true) return;
        try
        {
            await new ExcelService().ExportAsync(d.FileName, SelectedCompanyId);
            MessageBox.Show("خروجی Excel با موفقیت ذخیره شد.", "خروجی Excel", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show("خروجی Excel انجام نشد: " + ex.Message, "خطا", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private async void Backup_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanBackup) { MessageBox.Show("دسترسی پشتیبان‌گیری لازم است."); return; }
        try
        {
            var dlg = new OpenFolderDialog { Title = "پوشه ذخیره پشتیبان", Multiselect = false };
            if (dlg.ShowDialog() != true) return;
            var file = await Backup.CreateBackupAsync(dlg.FolderName);
            MessageBox.Show($"پشتیبان با موفقیت ایجاد شد:\n{file}", "پشتیبان‌گیری", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "پشتیبان‌گیری", MessageBoxButton.OK, MessageBoxImage.Error); }
    }

    private void Users_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin) { MessageBox.Show("فقط مدیر سیستم به مدیریت کاربران دسترسی دارد."); return; }
        PageHost.Content = new UserManagementView(CurrentUser.Id); SetActiveNav(BtnUsers);
    }

    private void Settings_Click(object sender, RoutedEventArgs e)
    {
        PageHost.Content = new SettingsView(); SetActiveNav(BtnSettings);
    }

    // Lets the user find a menu option by typing, instead of having to scroll and scan the
    // full sidebar list - matches against each button's Tag (or its visible label text if no
    // Tag was set) and hides everything that doesn't match.
    private void MenuSearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var query = MenuSearchBox.Text.Trim();
        MenuSearchPlaceholder.Visibility = string.IsNullOrEmpty(query) ? Visibility.Visible : Visibility.Collapsed;
        foreach (var child in NavItemsPanel.Children)
        {
            if (child is not Button b) continue;
            var label = b.Tag as string ?? NavButtonLabelText(b);
            b.Visibility = string.IsNullOrEmpty(query) || (label?.Contains(query, StringComparison.OrdinalIgnoreCase) ?? true)
                ? Visibility.Visible : Visibility.Collapsed;
        }
    }

    static string? NavButtonLabelText(Button b)
    {
        if (b.Content is not StackPanel sp) return b.Content as string;
        return sp.Children.OfType<TextBlock>().Skip(1).FirstOrDefault()?.Text;
    }

    private async void Restore_Click(object sender, RoutedEventArgs e)
    {
        if (!CurrentUser.IsAdmin && !CurrentUser.CanBackup) { MessageBox.Show("دسترسی بازیابی لازم است."); return; }
        var d=new OpenFileDialog{Filter="SQLite Database|*.db",Title="انتخاب فایل پشتیبان"}; if(d.ShowDialog()!=true)return;
        if(MessageBox.Show("بازیابی پایگاه داده باعث بسته شدن برنامه می‌شود. ادامه می‌دهید؟","تأیید بازیابی",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        try
        {
            var safety = await Backup.RestoreBackupAsync(d.FileName);
            MessageBox.Show(
                $"بازیابی انجام شد. نسخه ایمنی در:\n{safety}\n\nبرنامه را دوباره اجرا کنید.",
                "بازیابی",
                MessageBoxButton.OK,
                MessageBoxImage.Information);
            Application.Current.Shutdown();
        }
        catch(Exception ex)
        {
            MessageBox.Show(ex.Message, "بازیابی", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void CompanyFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (!_ready) return;
        await RefreshDashboard();
    }

    private async void Search_Click(object sender, RoutedEventArgs e)
    {
        var company = SelectedCompanyId;
        var search = InvoiceNumberSearch.Text.Trim();
        var rows = await S.GetInvoicesAsync(company, string.IsNullOrWhiteSpace(search) ? null : search);
        var status = (StatusFilter.SelectedItem as ComboBoxItem)?.Content?.ToString();
        if (!string.IsNullOrWhiteSpace(status) && status != "همه") rows = rows.Where(x => GetStatus(x) == status).ToList();
        if (!string.IsNullOrWhiteSpace(InvoiceSearchDate.Text) && InvoiceSearchDate.Text != "انتخاب تاریخ")
        {
            if (!PersianDateService.TryParse(InvoiceSearchDate.Text, out var invoiceDate)) { MessageBox.Show("تاریخ فاکتور معتبر نیست. نمونه: ۱۴۰۵/۰۵/۲۵", "جستجو", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            rows = rows.Where(x => x.InvoiceDate.Date == invoiceDate.Date).ToList();
        }
        if (!string.IsNullOrWhiteSpace(DueSearchDate.Text) && DueSearchDate.Text != "انتخاب تاریخ")
        {
            if (!PersianDateService.TryParse(DueSearchDate.Text, out var dueDate)) { MessageBox.Show("تاریخ سررسید معتبر نیست. نمونه: ۱۴۰۵/۰۶/۲۵", "جستجو", MessageBoxButton.OK, MessageBoxImage.Warning); return; }
            rows = rows.Where(x => x.DueDate.Date == dueDate.Date).ToList();
        }
        LatestInvoices.ItemsSource = rows.Take(50).Select((x, i) => new { Row = i + 1, Number = x.Number, InvoiceDate = PersianDateService.ToPersian(x.InvoiceDate), Company = x.Company?.Name ?? "-", Amount = x.Amount.ToString("N0"), Paid = x.Paid.ToString("N0"), Balance = AccountingService.Balance(x).ToString("N0"), DueDate = PersianDateService.ToPersian(x.DueDate), Status = GetStatus(x) }).ToList();
    }
    private async void ClearFilter_Click(object sender, RoutedEventArgs e) { CompanyFilter.SelectedIndex = 0; StatusFilter.SelectedIndex = 0; InvoiceNumberSearch.Clear(); InvoiceSearchDate.Text = "انتخاب تاریخ"; DueSearchDate.Text = "انتخاب تاریخ"; await RefreshDashboard(); }
    private void Exit_Click(object sender, RoutedEventArgs e) => Close();
}
