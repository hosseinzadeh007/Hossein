using System.Data;
using HesabGara.Domain;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Data;

/// <summary>
/// نسخه‌های قدیمی مبلغ «پرداخت‌شده» را مستقیم روی فاکتور نگه می‌داشتند (بدون رکورد Payment).
/// این مهاجرت، هر مبلغ بدون رکورد را به یک Payment تبدیل می‌کند تا Invoice.Paid همیشه برابر
/// جمع وصول‌ها باشد. باید قبل از هر همگام‌سازی Paid اجرا شود؛ در غیر این صورت آن مبالغ صفر می‌شدند.
/// عملیات idempotent است: اجرای دوباره چیزی اضافه نمی‌کند.
/// </summary>
public static class LegacyPaidMigration
{
    public const string MarkerKey = "Migration.LegacyPaidToPayments";
    public const string Note = "انتقال مبلغ پرداخت‌شده از نسخه‌های قبل";

    public static int Run(AppDbContext db)
    {
        // در حالت شبکه‌ای چند کلاینت ممکن است همزمان بالا بیایند؛ اجرا زیر قفل و تراکنش انجام می‌شود.
        var strategy = db.Database.CreateExecutionStrategy();
        return strategy.Execute(() => RunLocked(db));
    }

    static int RunLocked(AppDbContext db)
    {
        db.ChangeTracker.Clear();
        using var tx = db.Database.BeginTransaction(IsolationLevel.Serializable);
        if (db.Database.IsSqlServer())
            db.Database.ExecuteSqlRaw("DECLARE @r int; EXEC @r = sp_getapplock @Resource = N'HesabGara.LegacyPaidMigration', @LockMode = N'Exclusive', @LockOwner = N'Transaction', @LockTimeout = 60000; IF @r < 0 THROW 51000, N'Legacy paid migration lock timeout', 1;");

        if (db.Settings.Any(x => x.Key == MarkerKey)) { tx.Commit(); return 0; }

        var created = 0;
        foreach (var inv in db.Invoices.Include(x => x.Payments).ToList())
        {
            var recorded = Math.Min(inv.Paid, inv.Amount);
            var gap = recorded - inv.Payments.Sum(x => x.Amount);
            if (gap <= 0) continue;
            db.Payments.Add(new Payment { InvoiceId = inv.Id, Amount = gap, PayDate = inv.InvoiceDate.Date, PaymentMethod = PaymentMethods.Cash, Note = Note });
            created++;
        }
        if (created > 0)
            db.AuditLogs.Add(new AuditLog { TimestampUtc = DateTime.UtcNow, Action = "Migrate", Entity = "Payment", Details = $"LegacyPaid → Payments: {created} invoice(s)" });
        db.Settings.Add(new AppSetting { Key = MarkerKey, Value = DateTime.UtcNow.ToString("O") });
        db.SaveChanges();
        tx.Commit();
        return created;
    }
}
