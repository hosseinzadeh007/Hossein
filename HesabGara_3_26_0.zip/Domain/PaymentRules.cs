using HesabGara.Models;

namespace HesabGara.Domain;

/// <summary>روش‌های وصول مجاز و قواعد نرمال‌سازی اطلاعات چک (یک منبع واحد برای همه‌ی سرویس‌ها).</summary>
public static class PaymentMethods
{
    public const string Cash = "نقد";
    public const string Card = "کارت\u200cبه\u200cکارت";
    public const string Check = "چک";
    public const string Mixed = "ترکیبی";

    public static readonly string[] All = { Cash, Card, Check, Mixed };

    /// <summary>روش را trim می‌کند (خالی = نقد) و اگر مجاز نباشد خطا می‌دهد.</summary>
    public static string Normalize(string? method)
    {
        var value = string.IsNullOrWhiteSpace(method) ? Cash : method.Trim();
        if (!All.Contains(value, StringComparer.Ordinal)) throw new ArgumentException("روش وصول معتبر نیست.");
        return value;
    }
}

public static class PaymentRules
{
    public const string DefaultCheckStatus = "در انتظار وصول";
    public static readonly string[] CheckStatuses = { DefaultCheckStatus, "وصول\u200cشده", "برگشتی", "لغوشده" };

    /// <summary>وضعیت چک را با فهرست مجاز تطبیق می‌دهد (یکسان‌سازی ی/ک عربی و نیم‌فاصله)؛ نامعتبر = null.</summary>
    public static string? MatchCheckStatus(string? text)
    {
        static string Key(string s) => s.Trim().Replace('ي', 'ی').Replace('ك', 'ک').Replace("\u200c", "").Replace(" ", "");
        if (string.IsNullOrWhiteSpace(text)) return null;
        var k = Key(text);
        return CheckStatuses.FirstOrDefault(x => Key(x) == k);
    }

    /// <summary>اطلاعات چک فقط برای روش «چک» نگه‌داری می‌شود؛ برای بقیه‌ی روش‌ها پاک می‌شود.</summary>
    public static void NormalizeCheckFields(Payment p)
    {
        if (p.PaymentMethod == PaymentMethods.Check)
        {
            p.CheckNumber = string.IsNullOrWhiteSpace(p.CheckNumber) ? null : p.CheckNumber.Trim();
            p.CheckDate = p.CheckDate?.Date;
            if (string.IsNullOrWhiteSpace(p.CheckStatus)) p.CheckStatus = DefaultCheckStatus;
        }
        else
        {
            p.CheckNumber = null;
            p.CheckDate = null;
            p.CheckStatus = null;
        }
    }
}
