using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

public sealed partial class AccountingService
{
    public async Task<List<Company>> GetCompaniesAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        return await db.Companies.AsNoTracking().OrderBy(x => x.Name).ToListAsync(ct);
    }

    public async Task AddCompanyAsync(Company company, CancellationToken ct = default)
    {
        ValidateCompany(company);
        await using var db = new AppDbContext();
        if (await db.Companies.AnyAsync(x => x.Name == company.Name.Trim(), ct)) throw new InvalidOperationException("شرکتی با این نام قبلاً ثبت شده است.");
        company.Name = company.Name.Trim();
        db.Companies.Add(company);
        await db.SaveChangesAsync(ct);
        await AuditAsync("Create", "Company", company.Id.ToString(), company.Name, db, ct);
        await db.SaveChangesAsync(ct);
    }

    public async Task UpdateCompanyAsync(Company input, CancellationToken ct = default)
    {
        ValidateCompany(input);
        await using var db = new AppDbContext();
        var entity = await db.Companies.SingleOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new InvalidOperationException("شرکت پیدا نشد.");
        var name = input.Name.Trim();
        if (await db.Companies.AnyAsync(x => x.Id != input.Id && x.Name == name, ct)) throw new InvalidOperationException("شرکتی با این نام قبلاً ثبت شده است.");
        entity.Name = name; entity.NationalId = string.IsNullOrWhiteSpace(input.NationalId) ? null : input.NationalId.Trim(); entity.Phone = input.Phone?.Trim(); entity.Note = input.Note?.Trim();
        await db.SaveChangesAsync(ct);
        await AuditAsync("Update", "Company", entity.Id.ToString(), entity.Name, db, ct); await db.SaveChangesAsync(ct);
    }

    public async Task DeleteCompanyAsync(int companyId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var entity = await db.Companies.SingleOrDefaultAsync(x => x.Id == companyId, ct) ?? throw new InvalidOperationException("شرکت پیدا نشد.");
        if (await db.Invoices.AnyAsync(x => x.CompanyId == companyId, ct)) throw new InvalidOperationException("این شرکت دارای فاکتور است و برای حفظ سوابق مالی قابل حذف نیست. ابتدا فاکتورها را تعیین تکلیف کنید.");
        db.Companies.Remove(entity); await db.SaveChangesAsync(ct);
        await AuditAsync("Delete", "Company", companyId.ToString(), entity.Name, db, ct); await db.SaveChangesAsync(ct);
    }

    static void ValidateCompany(Company c)
    {
        if (string.IsNullOrWhiteSpace(c.Name)) throw new ArgumentException("نام شرکت الزامی است.");
        if (c.Name.Trim().Length > 200) throw new ArgumentException("نام شرکت بیش از حد طولانی است.");
    }
}
