using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

public sealed partial class AccountingService
{
    public async Task<List<Invoice>> GetInvoicesAsync(int? companyId = null, string? search = null, CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var q = db.Invoices.Include(x => x.Company).Include(x => x.Payments).AsNoTracking().AsQueryable();
        if (companyId.HasValue) q = q.Where(x => x.CompanyId == companyId.Value);
        if (!string.IsNullOrWhiteSpace(search))
        {
            var s = search.Trim();
            q = q.Where(x => x.Number.Contains(s) || (x.Company != null && x.Company.Name.Contains(s)));
        }
        return await q.OrderByDescending(x => x.InvoiceDate).ThenByDescending(x => x.Id).ToListAsync(ct);
    }

    public const string InitialPaymentNote = "پرداخت اولیه هنگام ثبت فاکتور";

    public async Task AddInvoiceAsync(Invoice invoice, CancellationToken ct = default)
    {
        if (invoice.CompanyId <= 0) throw new ArgumentException("شرکت فاکتور مشخص نشده است.");
        if (string.IsNullOrWhiteSpace(invoice.Number)) throw new ArgumentException("شماره فاکتور الزامی است.");
        if (invoice.Amount <= 0) throw new ArgumentException("مبلغ فاکتور باید بزرگ‌تر از صفر باشد.");
        if (invoice.DueDate.Date < invoice.InvoiceDate.Date) throw new ArgumentException("سررسید نمی‌تواند قبل از تاریخ فاکتور باشد.");
        invoice.Number = invoice.Number.Trim();

        // مبلغ پرداخت‌شده‌ی اولیه هم به‌صورت یک رکورد Payment ثبت می‌شود تا Paid همیشه برابر جمع وصول‌ها بماند.
        invoice.Paid = FinanceRules.ClampPaid(invoice.Amount, invoice.Paid);
        if (invoice.Paid > 0 && invoice.Payments.Count == 0)
            invoice.Payments.Add(new Payment { Amount = invoice.Paid, PayDate = invoice.InvoiceDate.Date, PaymentMethod = PaymentMethods.Cash, Note = InitialPaymentNote });

        await using var db = new AppDbContext();
        if (!await db.Companies.AnyAsync(x => x.Id == invoice.CompanyId, ct)) throw new InvalidOperationException("شرکت پیدا نشد.");
        if (await db.Invoices.AnyAsync(x => x.CompanyId == invoice.CompanyId && x.Number == invoice.Number, ct)) throw new InvalidOperationException("این شماره فاکتور برای این شرکت قبلاً ثبت شده است.");
        db.Invoices.Add(invoice);
        await db.SaveChangesAsync(ct);
        await AuditAsync("Create", "Invoice", invoice.Id.ToString(), invoice.Number, db, ct);
        await db.SaveChangesAsync(ct);
    }

    public async Task UpdateInvoiceAsync(Invoice input, CancellationToken ct = default)
    {
        if (input.CompanyId <= 0 || string.IsNullOrWhiteSpace(input.Number)) throw new ArgumentException("شرکت و شماره فاکتور الزامی است.");
        if (input.Amount <= 0) throw new ArgumentException("مبلغ فاکتور باید بزرگ‌تر از صفر باشد.");
        if (input.DueDate.Date < input.InvoiceDate.Date) throw new ArgumentException("سررسید نمی‌تواند قبل از تاریخ فاکتور باشد.");
        await using var db = new AppDbContext();
        var entity = await db.Invoices.Include(x => x.Payments).SingleOrDefaultAsync(x => x.Id == input.Id, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");
        if (await db.Invoices.AnyAsync(x => x.Id != input.Id && x.CompanyId == input.CompanyId && x.Number == input.Number.Trim(), ct)) throw new InvalidOperationException("این شماره فاکتور برای این شرکت قبلاً ثبت شده است.");
        var paid = entity.Payments.Sum(x => x.Amount);
        if (input.Amount < paid) throw new InvalidOperationException($"مبلغ فاکتور نمی‌تواند کمتر از پرداخت‌های ثبت‌شده ({paid:N0}) باشد.");
        entity.CompanyId = input.CompanyId; entity.Number = input.Number.Trim(); entity.InvoiceDate = input.InvoiceDate.Date; entity.DueDate = input.DueDate.Date; entity.Amount = input.Amount; entity.Paid = paid; entity.Note = input.Note?.Trim();
        await db.SaveChangesAsync(ct); await AuditAsync("Update", "Invoice", entity.Id.ToString(), entity.Number, db, ct); await db.SaveChangesAsync(ct);
    }

    public async Task DeleteInvoiceAsync(int invoiceId, CancellationToken ct = default)
    {
        await using var db = new AppDbContext(); await InTransactionAsync(db, async () => {
        var entity = await db.Invoices.Include(x => x.Payments).SingleOrDefaultAsync(x => x.Id == invoiceId, ct) ?? throw new InvalidOperationException("فاکتور پیدا نشد.");
        if (entity.Payments.Count > 0) throw new InvalidOperationException("فاکتور دارای پرداخت است و برای حفظ سوابق مالی حذف نمی‌شود. ابتدا پرداخت‌های آن را حذف/اصلاح کنید.");
        db.Invoices.Remove(entity); await db.SaveChangesAsync(ct); await AuditAsync("Delete", "Invoice", invoiceId.ToString(), entity.Number, db, ct); await db.SaveChangesAsync(ct); }, ct);
    }
}
