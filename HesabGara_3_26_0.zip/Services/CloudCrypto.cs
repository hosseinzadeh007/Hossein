using System.Security.Cryptography;
using System.Text;
using System.Text.Json;

namespace HesabGara.Services;

/// <summary>
/// رمزگذاری سرتاسری برای همگام‌سازی ابری. قالب باید دقیقاً با WebCrypto گوشی یکی باشد:
/// PBKDF2-HMAC-SHA256 (۲۵۰٬۰۰۰ دور، رمز UTF-8 با NFKC) ← کلید ۲۵۶ بیتی AES-GCM، IV ۱۲ بایتی، برچسب ۱۶ بایتی
/// که در انتهای ct می‌آید (ct = رمزشده || tag). رمز هرگز ارسال نمی‌شود.
/// </summary>
public static class CloudCrypto
{
    public const int Version = 1, Iterations = 250_000, SaltSize = 16, IvSize = 12, TagSize = 16, KeySize = 32;
    const string Kdf = "pbkdf2-sha256";

    sealed record Envelope(int v, string kdf, int iter, string salt, string iv, string ct);

    static byte[] DeriveKey(string password, byte[] salt, int iterations) =>
        Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(password.Normalize(NormalizationForm.FormKC)), salt, iterations, HashAlgorithmName.SHA256, KeySize);

    public static string Encrypt(string plaintext, string password)
    {
        if (string.IsNullOrEmpty(password)) throw new ArgumentException("رمز رمزگذاری خالی است.");
        var salt = RandomNumberGenerator.GetBytes(SaltSize);
        var iv = RandomNumberGenerator.GetBytes(IvSize);
        var data = Encoding.UTF8.GetBytes(plaintext);
        var cipher = new byte[data.Length];
        var tag = new byte[TagSize];
        using (var aes = new AesGcm(DeriveKey(password, salt, Iterations), TagSize)) aes.Encrypt(iv, data, cipher, tag);
        var all = new byte[cipher.Length + TagSize];
        Buffer.BlockCopy(cipher, 0, all, 0, cipher.Length);
        Buffer.BlockCopy(tag, 0, all, cipher.Length, TagSize);
        return JsonSerializer.Serialize(new Envelope(Version, Kdf, Iterations, Convert.ToBase64String(salt), Convert.ToBase64String(iv), Convert.ToBase64String(all)));
    }

    public static string Decrypt(string envelopeJson, string password)
    {
        Envelope e;
        byte[] salt, iv, all;
        try
        {
            e = JsonSerializer.Deserialize<Envelope>(envelopeJson) ?? throw new FormatException();
            salt = Convert.FromBase64String(e.salt);
            iv = Convert.FromBase64String(e.iv);
            all = Convert.FromBase64String(e.ct);
        }
        catch (Exception ex) when (ex is JsonException or FormatException or ArgumentNullException)
        {
            throw new InvalidOperationException("قالب داده‌ی ابری معتبر نیست.");
        }
        if (e.v != Version || e.kdf != Kdf || e.iter < 100_000 || e.iter > 2_000_000 || iv.Length != IvSize || all.Length < TagSize)
            throw new InvalidOperationException("قالب داده‌ی ابری معتبر نیست.");

        var cipher = all[..^TagSize];
        var tag = all[^TagSize..];
        var plain = new byte[cipher.Length];
        try
        {
            using var aes = new AesGcm(DeriveKey(password, salt, e.iter), TagSize);
            aes.Decrypt(iv, cipher, tag, plain);
        }
        catch (CryptographicException)
        {
            throw new InvalidOperationException("رمز اشتباه است یا داده آسیب دیده است.");
        }
        return Encoding.UTF8.GetString(plain);
    }
}
