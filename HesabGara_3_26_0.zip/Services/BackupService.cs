﻿using HesabGara.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Data.Sqlite;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

/// <summary>
/// پشتیبان‌گیری امن برای SQLite و SQL Server.
/// در SQL Server مسیر فایل باید روی خود سرور SQL قابل دسترس و قابل نوشتن باشد.
/// </summary>
public sealed class BackupService
{
    /// <summary>تعداد پیش‌فرض پشتیبان خودکاری که نگه داشته می‌شود.</summary>
    public const int DefaultKeepCount = 30;
    public const string KeepCountSettingKey = "BackupKeepCount";
    public const int RestoreSafetyKeepCount = 5;

    // فقط فایل‌هایی با الگوی دقیق نام پشتیبان خود برنامه حذف می‌شوند؛ هر فایل دیگری در پوشه دست‌نخورده می‌ماند.
    static readonly Regex BackupNamePattern = new(@"^HesabGara_\d{8}_\d{6}\.(db|bak)$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    /// <summary>
    /// جدیدترین <paramref name="keep"/> پشتیبان را نگه می‌دارد و بقیه را پاک می‌کند (بر اساس زمان داخل نام فایل).
    /// keep ≤ 0 یعنی «همه را نگه دار». تعداد فایل‌های حذف‌شده را برمی‌گرداند؛ خطای حذف هرگز بالا نمی‌آید.
    /// </summary>
    public static int PruneOldBackups(string folder, int keep)
    {
        if (keep <= 0 || string.IsNullOrWhiteSpace(folder) || !Directory.Exists(folder)) return 0;
        var stale = Directory.EnumerateFiles(folder)
            .Where(f => BackupNamePattern.IsMatch(Path.GetFileName(f)))
            .OrderByDescending(f => Path.GetFileName(f), StringComparer.OrdinalIgnoreCase)
            .Skip(keep)
            .ToList();
        foreach (var f in stale) TryDelete(f);
        return stale.Count(f => !File.Exists(f));
    }

    /// <summary>نسخه‌های ایمنی «before-restore» کنار دیتابیس را به <paramref name="keep"/> عدد آخر محدود می‌کند.</summary>
    public static int PruneRestoreSafetyCopies(string databasePath, int keep)
    {
        if (keep <= 0) return 0;
        var dir = Path.GetDirectoryName(databasePath);
        if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir)) return 0;
        var prefix = Path.GetFileName(databasePath) + ".before-restore-";
        var stale = Directory.EnumerateFiles(dir)
            .Where(f => Path.GetFileName(f).StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
            .OrderByDescending(f => Path.GetFileName(f), StringComparer.OrdinalIgnoreCase)
            .Skip(keep)
            .ToList();
        foreach (var f in stale) TryDelete(f);
        return stale.Count(f => !File.Exists(f));
    }

    // در تست‌ها همیشه SQLite است (AppDbContext هم تنظیمات ماشین را نادیده می‌گیرد).
    static DatabaseConfiguration CurrentConfig() =>
        AppDbContext.TestDatabasePathOverride.Value != null
            ? new DatabaseConfiguration { Provider = DatabaseProvider.Sqlite }
            : DatabaseConfigurationStore.Load();

    public async Task<string> CreateBackupAsync(string destinationFolder, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(destinationFolder))
            throw new ArgumentException("مسیر پشتیبان معتبر نیست.");

        Directory.CreateDirectory(destinationFolder);
        var cfg = CurrentConfig();

        if (cfg.Provider == DatabaseProvider.SqlServer)
        {
            var path = Path.Combine(destinationFolder,
                $"HesabGara_{DateTime.Now:yyyyMMdd_HHmmss}.bak");
            return await CreateSqlServerBackupAsync(path, ct);
        }

        var file = Path.Combine(destinationFolder,
            $"HesabGara_{DateTime.Now:yyyyMMdd_HHmmss}.db");

        await using var db = new AppDbContext();
        await db.Database.ExecuteSqlRawAsync("VACUUM INTO {0};", new object[] { file }, ct);
        if (!await IsValidSqliteDatabaseAsync(file, ct))
        {
            TryDelete(file);
            throw new InvalidOperationException("پشتیبان SQLite ایجاد شد ولی اعتبارسنجی آن موفق نبود.");
        }
        return file;
    }

    async Task<string> CreateSqlServerBackupAsync(string backupPath, CancellationToken ct)
    {
        var cfg = DatabaseConfigurationStore.Load();
        var cs = new SqlConnectionStringBuilder(cfg.ConnectionString);
        if (string.IsNullOrWhiteSpace(cs.InitialCatalog) ||
            string.Equals(cs.InitialCatalog, "master", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("نام دیتابیس SQL Server برای Backup معتبر نیست.");

        // BACKUP DATABASE writes on the SQL Server machine, not necessarily the client PC.
        await using var cn = new SqlConnection(cfg.ConnectionString);
        await cn.OpenAsync(ct);

        await using var cmd = cn.CreateCommand();
        cmd.CommandTimeout = 300;
        cmd.CommandText = """
            BACKUP DATABASE @db
            TO DISK = @path
            WITH INIT, CHECKSUM, COMPRESSION, STATS = 10;
            """;
        cmd.Parameters.AddWithValue("@db", cs.InitialCatalog);
        cmd.Parameters.AddWithValue("@path", backupPath);
        await cmd.ExecuteNonQueryAsync(ct);

        // Verify that SQL Server can see the backup and that the backup header is readable.
        await using var verify = cn.CreateCommand();
        verify.CommandTimeout = 60;
        verify.CommandText = "RESTORE VERIFYONLY FROM DISK = @path WITH CHECKSUM;";
        verify.Parameters.AddWithValue("@path", backupPath);
        await verify.ExecuteNonQueryAsync(ct);

        return backupPath;
    }

    public async Task<string> RestoreBackupAsync(string backupFile, CancellationToken ct = default)
    {
        if (!File.Exists(backupFile))
            throw new FileNotFoundException("فایل پشتیبان پیدا نشد.", backupFile);

        var cfg = CurrentConfig();
        if (cfg.Provider == DatabaseProvider.SqlServer)
            return await RestoreSqlServerBackupAsync(backupFile, ct);

        if (!await IsValidSqliteDatabaseAsync(backupFile, ct))
            throw new InvalidOperationException("فایل پشتیبان SQLite از نظر یکپارچگی معتبر نیست.");
        if (!await LooksLikeHesabGaraDatabaseAsync(backupFile, ct))
            throw new InvalidOperationException("این فایل، پشتیبان حساب‌گرا نیست (جدول‌های اصلی پیدا نشد). داده‌ها تغییری نکردند.");

        var current = AppDbContext.DatabasePath;
        if (string.Equals(Path.GetFullPath(backupFile), Path.GetFullPath(current), StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("فایل انتخاب‌شده همان پایگاه داده‌ی فعلی است.");

        var safety = current + ".before-restore-" + DateTime.Now.ToString("yyyyMMdd_HHmmss");

        // دیتابیس در حالت WAL کار می‌کند: بخشی از داده‌ها ممکن است فقط در فایل -wal باشد.
        // پس نسخه‌ی ایمنی باید با VACUUM INTO گرفته شود (کپی ساده‌ی فایل اصلی، داده‌های WAL را از دست می‌داد).
        if (File.Exists(current))
        {
            TryDelete(safety);
            await using var db = new AppDbContext();
            await db.Database.ExecuteSqlRawAsync("VACUUM INTO {0};", new object[] { safety }, ct);
            if (!await IsValidSqliteDatabaseAsync(safety, ct))
            {
                TryDelete(safety);
                throw new InvalidOperationException("ساخت نسخه‌ی ایمنی موفق نبود؛ بازیابی انجام نشد و داده‌ها دست‌نخورده ماندند.");
            }
        }

        // همه‌ی اتصال‌ها بسته شوند تا SQLite هنگام بستن، WAL قدیمی را روی فایل بازیابی‌شده اعمال نکند.
        SqliteConnection.ClearAllPools();

        var temp = current + ".restore-tmp";
        try
        {
            File.Copy(backupFile, temp, true);
            // -wal و -shm قدیمی متعلق به دیتابیس قبلی‌اند و نباید روی فایل بازیابی‌شده بمانند.
            foreach (var suffix in new[] { "-wal", "-shm" })
            {
                var stale = current + suffix;
                if (File.Exists(stale)) File.Delete(stale);
            }
            File.Move(temp, current, true);
        }
        catch
        {
            TryDelete(temp);
            throw;
        }
        PruneRestoreSafetyCopies(current, RestoreSafetyKeepCount);
        return safety;
    }

    async Task<string> RestoreSqlServerBackupAsync(string backupFile, CancellationToken ct)
    {
        var cfg = DatabaseConfigurationStore.Load();
        var cs = new SqlConnectionStringBuilder(cfg.ConnectionString);
        if (string.IsNullOrWhiteSpace(cs.InitialCatalog) ||
            string.Equals(cs.InitialCatalog, "master", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("نام دیتابیس مقصد معتبر نیست.");

        // The .bak path is interpreted by SQL Server, so it must be accessible to SQL Server.
        await using var master = new SqlConnection(
            new SqlConnectionStringBuilder(cfg.ConnectionString) { InitialCatalog = "master" }.ConnectionString);
        await master.OpenAsync(ct);

        await using var verify = master.CreateCommand();
        verify.CommandTimeout = 120;
        verify.CommandText = "RESTORE VERIFYONLY FROM DISK = @path WITH CHECKSUM;";
        verify.Parameters.AddWithValue("@path", backupFile);
        await verify.ExecuteNonQueryAsync(ct);

        await using var restore = master.CreateCommand();
        restore.CommandTimeout = 600;
        restore.CommandText = $"""
            ALTER DATABASE [{EscapeIdentifier(cs.InitialCatalog)}] SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
            RESTORE DATABASE [{EscapeIdentifier(cs.InitialCatalog)}]
            FROM DISK = @path WITH REPLACE, RECOVERY, CHECKSUM, STATS = 10;
            ALTER DATABASE [{EscapeIdentifier(cs.InitialCatalog)}] SET MULTI_USER;
            """;
        restore.Parameters.AddWithValue("@path", backupFile);
        await restore.ExecuteNonQueryAsync(ct);
        return backupFile;
    }

    static string EscapeIdentifier(string value) => value.Replace("]", "]]");

    static async Task<bool> LooksLikeHesabGaraDatabaseAsync(string path, CancellationToken ct)
    {
        await using var conn = new SqliteConnection($"Data Source={path};Mode=ReadOnly");
        await conn.OpenAsync(ct);
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name IN ('Companies','Invoices','Payments');";
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) == 3;
    }

    static async Task<bool> IsValidSqliteDatabaseAsync(string path, CancellationToken ct)
    {
        var cs = $"Data Source={path};Mode=ReadOnly;Foreign Keys=True";
        await using var conn = new SqliteConnection(cs);
        await conn.OpenAsync(ct);
        await using var cmd = conn.CreateCommand();
        cmd.CommandText = "PRAGMA integrity_check;";
        var result = Convert.ToString(await cmd.ExecuteScalarAsync(ct));
        if (!string.Equals(result, "ok", StringComparison.OrdinalIgnoreCase)) return false;

        cmd.CommandText = "PRAGMA foreign_key_check;";
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        return !await reader.ReadAsync(ct);
    }

    public static void TryDelete(string file)
    {
        try { if (File.Exists(file)) File.Delete(file); } catch { }
    }
}
