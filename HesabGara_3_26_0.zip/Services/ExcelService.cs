﻿using System.IO;
using System.Globalization;
using HesabGara.Data;
using HesabGara.Domain;
using HesabGara.Models;
using ClosedXML.Excel;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

public sealed record ExcelImportResult(int CompaniesAdded, int CompaniesSkipped, int InvoicesAdded, int InvoicesSkipped, int PaymentsAdded, int PaymentsSkipped, List<string> Errors);

public sealed class ExcelService
{
    public void ExportSimpleTemplate(string filePath)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("فاکتورها");
        WriteHeaders(ws, "نام شرکت", "شماره فاکتور", "تاریخ فاکتور", "تاریخ سررسید", "مبلغ", "پرداختی", "توضیحات");
        // یک ردیف نمونه‌ی پرشده، تا فرمت تاریخ و نحوه‌ی پر کردن واضح باشد. این ردیف را حذف یا با اطلاعات واقعی جایگزین کنید.
        ws.Cell(2,1).Value="نمونه شرکت"; ws.Cell(2,2).Value="INV-1001"; ws.Cell(2,3).Value=PersianDateService.ToPersian(DateTime.Today);
        ws.Cell(2,4).Value=PersianDateService.ToPersian(DateTime.Today.AddDays(30)); ws.Cell(2,5).Value=1000000; ws.Cell(2,6).Value=0; ws.Cell(2,7).Value="";
        ws.RightToLeft=true; ws.Columns().AdjustToContents(); ws.SheetView.FreezeRows(1);
        ws.Row(1).Style.Font.Bold=true; ws.Row(1).Style.Fill.BackgroundColor=XLColor.LightBlue;
        ws.Row(2).Style.Font.FontColor=XLColor.Gray; ws.Row(2).Style.Font.Italic=true;
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
        wb.SaveAs(filePath);
    }

    public async Task ExportAsync(string filePath, int? companyId = null)
    {
        using var db = new AppDbContext();
        var invoicesQ = db.Invoices.Include(x => x.Company).AsNoTracking().AsQueryable();
        if (companyId.HasValue) invoicesQ = invoicesQ.Where(x => x.CompanyId == companyId.Value);
        var invoices = await invoicesQ.OrderBy(x => x.InvoiceDate).ThenBy(x => x.Number).ToListAsync();
        var ids = invoices.Select(x => x.Id).ToHashSet();
        var paymentsQ = db.Payments.Include(x => x.Invoice!).ThenInclude(x => x.Company).AsNoTracking().AsQueryable();
        if (companyId.HasValue) paymentsQ = paymentsQ.Where(x => ids.Contains(x.InvoiceId));
        var payments = await paymentsQ.OrderBy(x => x.PayDate).ToListAsync();
        var companies = await db.Companies.AsNoTracking().Where(x => !companyId.HasValue || x.Id == companyId.Value).OrderBy(x => x.Name).ToListAsync();

        using var wb = new XLWorkbook();
        var wsC = wb.Worksheets.Add("شرکت ها");
        WriteHeaders(wsC, "شناسه", "نام شرکت", "شناسه ملی", "تلفن", "توضیحات");
        var r = 2;
        foreach (var c in companies) { wsC.Cell(r,1).Value=c.Id; wsC.Cell(r,2).Value=c.Name; wsC.Cell(r,3).Value=c.NationalId ?? ""; wsC.Cell(r,4).Value=c.Phone ?? ""; wsC.Cell(r,5).Value=c.Note ?? ""; r++; }

        var wsI = wb.Worksheets.Add("فاکتورها");
        WriteHeaders(wsI, "شناسه", "نام شرکت", "شماره فاکتور", "تاریخ فاکتور", "تاریخ سررسید", "مبلغ", "پرداختی", "مانده", "توضیحات");
        r = 2;
        foreach (var x in invoices) { wsI.Cell(r,1).Value=x.Id; wsI.Cell(r,2).Value=x.Company?.Name ?? ""; wsI.Cell(r,3).Value=x.Number; wsI.Cell(r,4).Value=PersianDateService.ToPersian(x.InvoiceDate); wsI.Cell(r,5).Value=PersianDateService.ToPersian(x.DueDate); wsI.Cell(r,6).Value=(double)x.Amount; wsI.Cell(r,7).Value=(double)x.Paid; wsI.Cell(r,8).FormulaA1=$"=MAX(0,F{r}-G{r})"; wsI.Cell(r,9).Value=x.Note ?? ""; r++; }

        var wsP = wb.Worksheets.Add("پرداخت ها");
        WriteHeaders(wsP, "شناسه", "نام شرکت", "شماره فاکتور", "تاریخ پرداخت", "مبلغ", "توضیحات", "روش وصول", "شماره چک", "تاریخ چک", "وضعیت چک");
        r = 2;
        foreach (var p in payments) { wsP.Cell(r,1).Value=p.Id; wsP.Cell(r,2).Value=p.Invoice?.Company?.Name ?? ""; wsP.Cell(r,3).Value=p.Invoice?.Number ?? ""; wsP.Cell(r,4).Value=PersianDateService.ToPersian(p.PayDate); wsP.Cell(r,5).Value=(double)p.Amount; wsP.Cell(r,6).Value=p.Note ?? ""; wsP.Cell(r,7).Value=p.PaymentMethod; wsP.Cell(r,8).Value=p.CheckNumber ?? ""; wsP.Cell(r,9).Value=p.CheckDate.HasValue ? PersianDateService.ToPersian(p.CheckDate.Value) : ""; wsP.Cell(r,10).Value=p.CheckStatus ?? ""; r++; }

        foreach (var ws in wb.Worksheets) { ws.RightToLeft = true; ws.Columns().AdjustToContents(); ws.SheetView.FreezeRows(1); ws.Row(1).Style.Font.Bold = true; ws.Row(1).Style.Fill.BackgroundColor = XLColor.LightBlue; }
        Directory.CreateDirectory(Path.GetDirectoryName(filePath)!);
        wb.SaveAs(filePath);
    }

    public async Task<ExcelImportResult> ImportAsync(string filePath)
    {
        var errors = new List<string>();
        int ca=0, cs=0, ia=0, ins=0, pa=0, ps=0;
        using var wb = new XLWorkbook(filePath);
        using var db = new AppDbContext();
        var companyMap = await db.Companies.ToDictionaryAsync(x => Normalize(x.Name), x => x);

        var companySheet = FindSheet(wb, "شرکت ها", "شرکت‌ها", "شرکت ها و فروشندگان", "Companies");
        if (companySheet != null)
        {
            foreach (var row in DataRows(companySheet))
            {
                var name = Text(row, "نام شرکت", "نام", "Company"); if (string.IsNullOrWhiteSpace(name)) { cs++; continue; }
                var key = Normalize(name);
                var nationalId = NullIfEmpty(Text(row,"شناسه ملی","کد ملی","NationalId"));
                if (companyMap.ContainsKey(key) || (!string.IsNullOrWhiteSpace(nationalId) && await db.Companies.AnyAsync(x => x.NationalId == nationalId))) { cs++; continue; }
                var c = new Company { Name=name.Trim(), NationalId=nationalId, Phone=NullIfEmpty(Text(row,"تلفن","شماره تماس","Phone")), Note=NullIfEmpty(Text(row,"توضیحات","یادداشت","Note")) };
                db.Companies.Add(c); await db.SaveChangesAsync(); companyMap[key]=c; ca++;
            }
        }

        var invoiceSheet = FindSheet(wb, "فاکتورها", "فاکتور", "Invoices")
            ?? (wb.Worksheets.Count == 1 ? wb.Worksheets.First() : null); // فایل ساده: اگر فقط یک شیت دارد، همان به‌عنوان فاکتورها در نظر گرفته می‌شود
        var paymentSheet = FindSheet(wb, "پرداخت ها", "پرداخت‌ها", "پرداخت", "Payments");
        var hasPaymentSheet = paymentSheet != null;
        if (invoiceSheet != null)
        {
            foreach (var row in DataRows(invoiceSheet))
            {
                try
                {
                    var companyName=Text(row,"نام شرکت","شرکت","فروشنده","Company"); var number=Text(row,"شماره فاکتور","شماره","Invoice Number");
                    if (string.IsNullOrWhiteSpace(companyName) || string.IsNullOrWhiteSpace(number)) { ins++; continue; }
                    var key = Normalize(companyName);
                    if (!companyMap.TryGetValue(key, out var c))
                    {
                        // فایل ساده: شرکتی که از قبل نیست، فقط با همین نام خودکار ساخته می‌شود
                        // (به‌جای رد کردن ردیف با خطای «شرکت پیدا نشد»)
                        c = new Company { Name = companyName.Trim() };
                        db.Companies.Add(c);
                        await db.SaveChangesAsync();
                        companyMap[key] = c;
                        ca++;
                    }
                    if (await db.Invoices.AnyAsync(x=>x.CompanyId==c.Id && x.Number==number.Trim())) { ins++; continue; }
                    var amount=Decimal(row,"مبلغ","مبلغ کل","Amount"); var paid=Decimal(row,"پرداختی","پرداخت شده","Paid");
                    if (amount<=0) { errors.Add($"مبلغ فاکتور «{number}» معتبر نیست."); ins++; continue; }
                    var date=Date(row,"تاریخ فاکتور","تاریخ","Invoice Date") ?? DateTime.Today;
                    var due=Date(row,"تاریخ سررسید","سررسید","Due Date") ?? date;
                    var initialPaid = hasPaymentSheet ? 0 : Math.Min(Math.Max(0, paid), amount);
                    var newInvoice = new Invoice { CompanyId=c.Id, Number=number.Trim(), InvoiceDate=date, DueDate=due, Amount=amount, Paid=initialPaid, Note=NullIfEmpty(Text(row,"توضیحات","یادداشت","Note")) };
                    // Paid فقط از روی رکوردهای Payment معنا دارد؛ پس مبلغ ستون «پرداختی» هم یک Payment می‌شود.
                    if (initialPaid > 0) newInvoice.Payments.Add(new Payment { Amount=initialPaid, PayDate=date, PaymentMethod=PaymentMethods.Cash, Note="پرداختی واردشده از فایل اکسل" });
                    db.Invoices.Add(newInvoice);
                    await db.SaveChangesAsync(); ia++;
                }
                catch(Exception ex){ errors.Add("خطا در فاکتور: "+ex.Message); ins++; }
            }
        }

        var invoiceMap = await db.Invoices.Include(x=>x.Company).ToDictionaryAsync(x => Normalize(x.Company!.Name)+"|"+Normalize(x.Number), x=>x);
        if (paymentSheet != null)
        {
            foreach (var row in DataRows(paymentSheet))
            {
                try
                {
                    var companyName=Text(row,"نام شرکت","شرکت","فروشنده","Company"); var number=Text(row,"شماره فاکتور","شماره","Invoice Number"); var amount=Decimal(row,"مبلغ","مبلغ پرداخت","Amount");
                    if (string.IsNullOrWhiteSpace(companyName)||string.IsNullOrWhiteSpace(number)||amount<=0){ps++;continue;}
                    if(!invoiceMap.TryGetValue(Normalize(companyName)+"|"+Normalize(number),out var inv)){errors.Add($"فاکتور «{number}» برای پرداخت پیدا نشد.");ps++;continue;}
                    var date=Date(row,"تاریخ پرداخت","تاریخ","Pay Date")??DateTime.Today;
                    var existing=await db.Payments.AnyAsync(x=>x.InvoiceId==inv.Id && x.PayDate.Date==date.Date && x.Amount==amount);
                    if(existing){ps++;continue;}
                    var remaining=AccountingService.Balance(inv); if(remaining<=0){ps++;continue;}
                    amount=Math.Min(amount,remaining);
                    inv.Paid += amount;
                    var methodText=Text(row,"روش وصول","روش پرداخت","روش","Method");
                    var method=PaymentMethods.Cash;
                    if(!string.IsNullOrWhiteSpace(methodText)){ try{ method=PaymentMethods.Normalize(methodText); } catch(ArgumentException){ errors.Add($"روش وصول «{methodText}» برای فاکتور «{number}» معتبر نبود؛ نقد ثبت شد."); } }
                    var newPayment=new Payment{InvoiceId=inv.Id,PayDate=date,Amount=amount,PaymentMethod=method,Note=NullIfEmpty(Text(row,"توضیحات","یادداشت","Note"))};
                    if(method==PaymentMethods.Check)
                    {
                        newPayment.CheckNumber=NullIfEmpty(Text(row,"شماره چک","Check Number"));
                        newPayment.CheckDate=Date(row,"تاریخ چک","Check Date");
                        newPayment.CheckStatus=PaymentRules.MatchCheckStatus(Text(row,"وضعیت چک","Check Status"));
                    }
                    PaymentRules.NormalizeCheckFields(newPayment);
                    db.Payments.Add(newPayment);
                    await db.SaveChangesAsync(); pa++;
                }
                catch(Exception ex){errors.Add("خطا در پرداخت: "+ex.Message);ps++;}
            }
        }
        return new ExcelImportResult(ca,cs,ia,ins,pa,ps,errors);
    }

    static void WriteHeaders(IXLWorksheet ws, params string[] headers){for(int i=0;i<headers.Length;i++)ws.Cell(1,i+1).Value=headers[i];}
    static IXLWorksheet? FindSheet(XLWorkbook wb, params string[] names){return wb.Worksheets.FirstOrDefault(s=>names.Any(n=>Normalize(s.Name)==Normalize(n)));}
    static IEnumerable<IXLRow> DataRows(IXLWorksheet ws)=>ws.RowsUsed().Skip(1).Where(r=>r.CellsUsed().Any(c=>!string.IsNullOrWhiteSpace(c.GetString())));
    static string Text(IXLRow r, params string[] names){foreach(var c in r.CellsUsed()){var header=r.Worksheet.Cell(1,c.Address.ColumnNumber).GetString();if(names.Any(n=>Normalize(header)==Normalize(n)))return c.GetString().Trim();}return "";}
    static decimal Decimal(IXLRow r, params string[] names){var s=Text(r,names).Replace(",","").Replace("٬","").Trim(); if(decimal.TryParse(s,NumberStyles.Any,CultureInfo.InvariantCulture,out var d))return d;if(decimal.TryParse(s,NumberStyles.Any,new CultureInfo("fa-IR"),out d))return d;return 0;}
    static DateTime? Date(IXLRow r, params string[] names){var cell=FindCell(r,names); if(cell==null)return null; if(cell.DataType==XLDataType.DateTime)return cell.GetDateTime(); var s=cell.GetString().Trim(); if(PersianDateService.TryParse(s,out var d))return d;if(DateTime.TryParse(s,new CultureInfo("fa-IR"),DateTimeStyles.None,out d))return d;if(DateTime.TryParse(s,out d))return d;return null;}
    static IXLCell? FindCell(IXLRow r,string[] names){foreach(var c in r.CellsUsed()){var h=r.Worksheet.Cell(1,c.Address.ColumnNumber).GetString();if(names.Any(n=>Normalize(h)==Normalize(n)))return c;}return null;}
    static string Normalize(string? s)=>string.Join(' ',(s??"").Trim().Replace('ي','ی').Replace('ك','ک').Split((char[])null!,StringSplitOptions.RemoveEmptyEntries)).ToLowerInvariant();
    static string? NullIfEmpty(string s)=>string.IsNullOrWhiteSpace(s)?null:s;
}
