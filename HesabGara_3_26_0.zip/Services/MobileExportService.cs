using System.Text;
using System.Text.Encodings.Web;
using System.Text.Json;
using HesabGara.Data;
using Microsoft.EntityFrameworkCore;

namespace HesabGara.Services;

/// <summary>
/// خروجی فقط‌خواندنی برای اپ موبایل: یک فایل JSON شامل شرکت‌ها، فاکتورها و وصول‌ها (با تاریخ شمسی و میلادی).
/// این فایل رمزگذاری نمی‌شود؛ مثل هر فایل مالی دیگر باید محرمانه نگه داشته شود.
/// </summary>
public sealed class MobileExportService
{
    public const int FormatVersion = 1;

    public async Task<string> BuildJsonAsync(CancellationToken ct = default)
    {
        await using var db = new AppDbContext();
        var companies = await db.Companies.AsNoTracking().OrderBy(x => x.Name).ToListAsync(ct);
        var invoices = await db.Invoices.AsNoTracking().OrderBy(x => x.InvoiceDate).ThenBy(x => x.Id).ToListAsync(ct);
        var payments = await db.Payments.AsNoTracking().OrderBy(x => x.PayDate).ThenBy(x => x.Id).ToListAsync(ct);

        static string Iso(DateTime d) => d.ToString("yyyy-MM-dd");
        var now = DateTime.Now;
        var data = new
        {
            app = "HesabGara",
            format = FormatVersion,
            exportedAt = now.ToString("yyyy-MM-ddTHH:mm:ss"),
            exportedAtFa = PersianDateService.ToPersian(now) + " " + now.ToString("HH:mm"),
            companies = companies.Select(c => new { id = c.Id, name = c.Name, phone = c.Phone, nationalId = c.NationalId }),
            invoices = invoices.Select(i => new
            {
                id = i.Id, companyId = i.CompanyId, number = i.Number,
                date = Iso(i.InvoiceDate), dateFa = PersianDateService.ToPersian(i.InvoiceDate),
                due = Iso(i.DueDate), dueFa = PersianDateService.ToPersian(i.DueDate),
                amount = i.Amount, paid = i.Paid, note = i.Note
            }),
            payments = payments.Select(p => new
            {
                id = p.Id, invoiceId = p.InvoiceId, amount = p.Amount,
                date = Iso(p.PayDate), dateFa = PersianDateService.ToPersian(p.PayDate),
                method = p.PaymentMethod, checkNumber = p.CheckNumber,
                checkDateFa = p.CheckDate.HasValue ? PersianDateService.ToPersian(p.CheckDate.Value) : null,
                checkStatus = p.CheckStatus, note = p.Note
            })
        };

        var json = JsonSerializer.Serialize(data, new JsonSerializerOptions { Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping });
        return json;
    }

    public async Task ExportAsync(string filePath, CancellationToken ct = default)
    {
        var json = await BuildJsonAsync(ct);
        Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(filePath))!);
        var temp = filePath + ".tmp";
        await File.WriteAllTextAsync(temp, json, new UTF8Encoding(false), ct);
        File.Move(temp, filePath, true);
    }
}
