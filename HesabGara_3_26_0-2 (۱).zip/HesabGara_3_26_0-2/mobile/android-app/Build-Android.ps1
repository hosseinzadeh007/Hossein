﻿# ساخت APK اندروید حساب‌گرا با یک دستور:  .\Build-Android.ps1
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot

function Need($cmd, $hint) { if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "$cmd پیدا نشد. $hint" } }
Need node 'Node.js 18 یا بالاتر را از nodejs.org نصب کنید.'
Need java 'JDK 17 لازم است (Android Studio آن را همراه دارد؛ JAVA_HOME را هم تنظیم کنید).'

if (-not $env:ANDROID_HOME -and -not $env:ANDROID_SDK_ROOT) {
  $default = Join-Path $env:LOCALAPPDATA 'Android\Sdk'
  if (Test-Path $default) { $env:ANDROID_HOME = $default }
  else { throw 'Android SDK پیدا نشد. Android Studio را نصب و یک بار باز کنید تا SDK دانلود شود.' }
}
$sdk = if ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { $env:ANDROID_SDK_ROOT }

npm install
if (-not (Test-Path 'android')) { npx cap add android }
npm run icons
npx cap sync android
"sdk.dir=$($sdk -replace '\\','/')" | Set-Content 'android\local.properties' -Encoding ascii

Push-Location 'android'
try { .\gradlew.bat assembleDebug } finally { Pop-Location }

$apk = 'android\app\build\outputs\apk\debug\app-debug.apk'
if (-not (Test-Path $apk)) { throw 'APK ساخته نشد؛ خروجی Gradle را بخوانید.' }
Copy-Item $apk '..\HesabGara-mobile.apk' -Force
Write-Host 'APK آماده است: mobile\HesabGara-mobile.apk' -ForegroundColor Green
